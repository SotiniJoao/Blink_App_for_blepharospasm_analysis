import imutils
from imutils import face_utils
import dlib
import cv2
from MódulosBlefaro1.EAR import EAR

def Captura(OLHO_AR_THRESH):
    detector = dlib.get_frontal_face_detector()
    predictor = dlib.shape_predictor('eye_predictor.dat')
    (lStart, lEnd) = (0,6)
    (rStart, rEnd) = (6,12)
    total = 0
    txdeframes = []
    cont = 0
    vet = []
    quadros = 0
    OLHO_AR_FRAMES = 3
    captura = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    captura.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
    captura.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)
    while True:
        ret, frame = captura.read()
        quadros += 1
        if not ret:
            break
        frame = imutils.resize(frame, width=500)
        gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        s, thresh = cv2.threshold(gray_frame, 35, 255, cv2.THRESH_BINARY_INV)
        faces = detector(gray_frame, 0)
        for face in faces:
            shape = predictor(gray_frame, face)
            shape = face_utils.shape_to_np(shape)
            Olhoesq = shape[lStart:lEnd]
            Olhodir = shape[rStart:rEnd]
            EAResq = EAR(Olhoesq)
            EARdir = EAR(Olhodir)
            ear = (EAResq + EARdir) / 2.0
            vet.append(ear)
            Hullesq = cv2.convexHull(Olhoesq)
            Hulldir = cv2.convexHull(Olhodir)
            cv2.drawContours(frame, [Hullesq], -1, (255, 0, 0), 1)
            cv2.drawContours(frame, [Hulldir], -1, (0, 0, 255), 1)
            if ear < OLHO_AR_THRESH:
                cont += 1
            elif cont >= OLHO_AR_FRAMES:
                total += 1
                cont = 0
            cv2.putText(frame, "Piscadas: {}".format(total), (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            cv2.putText(frame, "ear: {:.2f}".format(ear), (300, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        txdeframes.append(quadros / 30)
        cv2.imshow('Contador', frame)
        key = cv2.waitKey(1)
        if key == 27:
            break
    cv2.destroyAllWindows()
    return vet, txdeframes,quadros